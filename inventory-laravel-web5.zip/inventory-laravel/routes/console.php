<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('about-project', function () {
    $this->comment('Inventory Management System - Laravel Fundamental');
})->purpose('Show project information');
