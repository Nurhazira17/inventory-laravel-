@extends('layouts.app')
@section('title', 'Tambah Kategori')
@section('content')
<div class="panel"><h1>Tambah Kategori</h1><form method="POST" action="{{ route('categories.store') }}">@csrf @include('categories._form')<button class="btn">Simpan</button> <a class="btn secondary" href="{{ route('categories.index') }}">Batal</a></form></div>
@endsection
