@extends('layouts.app')
@section('title', 'Kategori')
@section('content')
<div class="panel"><h1>Daftar Kategori</h1><a class="btn" href="{{ route('categories.create') }}">+ Tambah Kategori</a></div>
<div class="panel"><table><thead><tr><th>Nama</th><th>Deskripsi</th><th>Jumlah Produk</th><th>Aksi</th></tr></thead><tbody>
@forelse($categories as $category)<tr><td>{{ $category->name }}</td><td>{{ $category->description ?: '-' }}</td><td>{{ $category->products_count }}</td><td><div class="actions"><a class="btn" href="{{ route('categories.edit', $category) }}">Edit</a><form method="POST" action="{{ route('categories.destroy', $category) }}" onsubmit="return confirm('Hapus kategori ini?')">@csrf @method('DELETE')<button class="btn danger">Hapus</button></form></div></td></tr>@empty<tr><td colspan="4">Belum ada kategori.</td></tr>@endforelse
</tbody></table>{{ $categories->links() }}</div>
@endsection
