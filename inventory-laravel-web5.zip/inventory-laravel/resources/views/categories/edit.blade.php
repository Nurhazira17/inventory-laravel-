@extends('layouts.app')
@section('title', 'Edit Kategori')
@section('content')
<div class="panel"><h1>Edit Kategori</h1><form method="POST" action="{{ route('categories.update', $category) }}">@csrf @method('PUT') @include('categories._form')<button class="btn">Simpan Perubahan</button> <a class="btn secondary" href="{{ route('categories.index') }}">Batal</a></form></div>
@endsection
