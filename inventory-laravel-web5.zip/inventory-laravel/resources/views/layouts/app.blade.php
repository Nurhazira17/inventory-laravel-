<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Inventory Management System')</title>
    <style>
        :root{font-family:Arial,sans-serif;color:#202938;background:#f4f6fb}body{margin:0}header{background:#172554;color:white;padding:18px 5%;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}header a{color:white;text-decoration:none;margin-right:16px}main{max-width:1100px;margin:28px auto;padding:0 16px}.panel{background:white;border-radius:12px;padding:20px;box-shadow:0 3px 14px #17255412;margin-bottom:18px}h1{margin-top:0}.btn{display:inline-block;border:0;border-radius:7px;padding:10px 14px;background:#1d4ed8;color:white;text-decoration:none;cursor:pointer;font-size:14px}.btn.secondary{background:#475569}.btn.danger{background:#b91c1c}input,select,textarea{box-sizing:border-box;padding:10px;border:1px solid #cbd5e1;border-radius:7px;width:100%;margin:5px 0 12px}label{font-weight:600;font-size:14px}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:11px;border-bottom:1px solid #e2e8f0;font-size:14px}th{background:#f8fafc}.status{font-weight:bold}.success{background:#dcfce7;color:#166534;padding:12px;border-radius:7px;margin-bottom:12px}.error{background:#fee2e2;color:#991b1b;padding:12px;border-radius:7px;margin-bottom:12px}.muted{color:#64748b}.filters{display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:10px;align-items:end}.actions{display:flex;gap:7px;flex-wrap:wrap}.pagination{margin-top:18px} @media(max-width:700px){.filters{grid-template-columns:1fr}table{display:block;overflow-x:auto}}
    </style>
</head>
<body>
<header>
    <strong>Inventory Management System</strong>
    <nav><a href="{{ route('products.index') }}">Produk</a><a href="{{ route('categories.index') }}">Kategori</a></nav>
</header>
<main>
    @if(session('success')) <div class="success">{{ session('success') }}</div> @endif
    @if(session('error')) <div class="error">{{ session('error') }}</div> @endif
    @if($errors->any())
        <div class="error"><strong>Periksa kembali input:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif
    @yield('content')
</main>
</body>
</html>
