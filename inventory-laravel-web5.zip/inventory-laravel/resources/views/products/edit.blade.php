@extends('layouts.app')
@section('title', 'Edit Produk')
@section('content')
<div class="panel"><h1>Edit Produk</h1>
<form method="POST" action="{{ route('products.update', $product) }}">@csrf @method('PUT') @include('products._form')<button class="btn" type="submit">Simpan Perubahan</button> <a class="btn secondary" href="{{ route('products.index') }}">Batal</a></form>
</div>
@endsection
