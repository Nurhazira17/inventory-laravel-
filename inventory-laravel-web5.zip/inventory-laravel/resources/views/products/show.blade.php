@extends('layouts.app')
@section('title', 'Detail Produk')
@section('content')
<div class="panel"><h1>Detail Produk</h1>
<table><tbody>
<tr><th>SKU</th><td>{{ $product->sku }}</td></tr><tr><th>Nama</th><td>{{ $product->name }}</td></tr><tr><th>Kategori</th><td>{{ $product->category->name }}</td></tr><tr><th>Deskripsi</th><td>{{ $product->description ?: '-' }}</td></tr><tr><th>Harga</th><td>Rp {{ number_format((float)$product->price, 0, ',', '.') }}</td></tr><tr><th>Stok</th><td>{{ $product->stock }}</td></tr><tr><th>Minimum stok</th><td>{{ $product->minimum_stock }}</td></tr><tr><th>Status</th><td>{{ $product->stock_status }}</td></tr>
</tbody></table><p><a class="btn" href="{{ route('products.edit', $product) }}">Edit</a> <a class="btn secondary" href="{{ route('products.index') }}">Kembali</a></p>
</div>
@endsection
