<div>
    <label for="category_id">Kategori *</label>
    <select id="category_id" name="category_id" required><option value="">Pilih kategori</option>@foreach($categories as $category)<option value="{{ $category->id }}" @selected(old('category_id', $product->category_id ?? '') == $category->id)>{{ $category->name }}</option>@endforeach</select>
    <label for="sku">SKU *</label><input id="sku" name="sku" value="{{ old('sku', $product->sku ?? '') }}" required maxlength="50">
    <label for="name">Nama Produk *</label><input id="name" name="name" value="{{ old('name', $product->name ?? '') }}" required maxlength="150">
    <label for="description">Deskripsi</label><textarea id="description" name="description" rows="3">{{ old('description', $product->description ?? '') }}</textarea>
    <label for="price">Harga (Rp) *</label><input id="price" type="number" min="0" step="0.01" name="price" value="{{ old('price', $product->price ?? '') }}" required>
    <label for="stock">Stok *</label><input id="stock" type="number" min="0" name="stock" value="{{ old('stock', $product->stock ?? 0) }}" required>
    <label for="minimum_stock">Batas Minimum Stok *</label><input id="minimum_stock" type="number" min="0" name="minimum_stock" value="{{ old('minimum_stock', $product->minimum_stock ?? 5) }}" required>
</div>
