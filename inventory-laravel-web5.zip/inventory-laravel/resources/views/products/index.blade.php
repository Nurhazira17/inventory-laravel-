@extends('layouts.app')
@section('title', 'Daftar Produk')
@section('content')
<div class="panel">
    <h1>Daftar Produk</h1>
    <p class="muted">Pantau stok, harga, dan kategori barang dalam satu halaman.</p>
    <a class="btn" href="{{ route('products.create') }}">+ Tambah Produk</a>
</div>
<div class="panel">
    <form class="filters" method="GET" action="{{ route('products.index') }}">
        <div><label for="search">Cari produk / SKU</label><input id="search" name="search" value="{{ request('search') }}" placeholder="Contoh: mouse"></div>
        <div><label for="category_id">Kategori</label><select id="category_id" name="category_id"><option value="">Semua kategori</option>@foreach($categories as $category)<option value="{{ $category->id }}" @selected(request('category_id') == $category->id)>{{ $category->name }}</option>@endforeach</select></div>
        <div><label for="stock_status">Status stok</label><select id="stock_status" name="stock_status"><option value="">Semua status</option><option value="low" @selected(request('stock_status')==='low')>Stok menipis</option><option value="empty" @selected(request('stock_status')==='empty')>Habis</option></select></div>
        <button class="btn" type="submit">Terapkan</button>
    </form>
    <p><a href="{{ route('products.index', ['sort' => 'name']) }}">Urut nama</a> · <a href="{{ route('products.index', ['sort' => 'price']) }}">Urut harga</a> · <a href="{{ route('products.index') }}">Reset filter</a></p>
    <table>
        <thead><tr><th>SKU</th><th>Nama Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
        @forelse($products as $product)
            <tr>
                <td>{{ $product->sku }}</td><td>{{ $product->name }}</td><td>{{ $product->category->name }}</td>
                <td>Rp {{ number_format((float)$product->price, 0, ',', '.') }}</td><td>{{ $product->stock }}</td>
                <td class="status">{{ $product->stock_status }}</td>
                <td><div class="actions"><a class="btn secondary" href="{{ route('products.show', $product) }}">Detail</a><a class="btn" href="{{ route('products.edit', $product) }}">Edit</a><form method="POST" action="{{ route('products.destroy', $product) }}" onsubmit="return confirm('Hapus produk ini?')">@csrf @method('DELETE')<button class="btn danger" type="submit">Hapus</button></form></div></td>
            </tr>
        @empty <tr><td colspan="7">Belum ada produk yang cocok.</td></tr> @endforelse
        </tbody>
    </table>
    <div class="pagination">{{ $products->links() }}</div>
</div>
@endsection
