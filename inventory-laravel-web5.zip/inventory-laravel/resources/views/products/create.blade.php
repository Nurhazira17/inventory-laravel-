@extends('layouts.app')
@section('title', 'Tambah Produk')
@section('content')
<div class="panel"><h1>Tambah Produk</h1>
<form method="POST" action="{{ route('products.store') }}">@csrf @include('products._form')<button class="btn" type="submit">Simpan Produk</button> <a class="btn secondary" href="{{ route('products.index') }}">Batal</a></form>
</div>
@endsection
