<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $categories = collect([
            ['name' => 'Elektronik', 'description' => 'Perangkat elektronik dan aksesorinya'],
            ['name' => 'Alat Tulis', 'description' => 'Perlengkapan belajar dan kantor'],
            ['name' => 'Kebutuhan Harian', 'description' => 'Barang kebutuhan sehari-hari'],
        ])->map(fn ($data) => Category::create($data));

        $products = [
            ['category_id' => $categories[0]->id, 'sku' => 'EL-0001', 'name' => 'Mouse Wireless', 'description' => 'Mouse nirkabel', 'price' => 85000, 'stock' => 20, 'minimum_stock' => 5],
            ['category_id' => $categories[0]->id, 'sku' => 'EL-0002', 'name' => 'Kabel USB', 'description' => 'Kabel data USB', 'price' => 25000, 'stock' => 3, 'minimum_stock' => 5],
            ['category_id' => $categories[1]->id, 'sku' => 'AT-0001', 'name' => 'Buku Tulis', 'description' => 'Buku tulis 38 lembar', 'price' => 5000, 'stock' => 0, 'minimum_stock' => 10],
            ['category_id' => $categories[1]->id, 'sku' => 'AT-0002', 'name' => 'Pulpen Hitam', 'description' => 'Pulpen tinta hitam', 'price' => 3000, 'stock' => 50, 'minimum_stock' => 10],
            ['category_id' => $categories[2]->id, 'sku' => 'KH-0001', 'name' => 'Sabun Cair', 'description' => 'Sabun cair serbaguna', 'price' => 18000, 'stock' => 12, 'minimum_stock' => 5],
        ];
        foreach ($products as $product) {
            Product::create($product);
        }
    }
}
